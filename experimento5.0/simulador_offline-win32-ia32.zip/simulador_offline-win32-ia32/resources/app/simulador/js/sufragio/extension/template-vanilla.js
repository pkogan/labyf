class TemplateFlavor extends Templates {

}

templateClass = new TemplateFlavor(get_modo(), constants);