class TemplateMedialuna extends Templates {

}

templateClass = new TemplateMedialuna(get_modo(), constants);