class TemplateMilanga extends Templates {

}

templateClass = new TemplateMilanga(get_modo(), constants);