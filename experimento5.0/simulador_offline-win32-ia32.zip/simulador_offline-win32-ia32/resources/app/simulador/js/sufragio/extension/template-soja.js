class TemplateSoja extends Templates {

}

templateClass = new TemplateSoja(get_modo(), constants);